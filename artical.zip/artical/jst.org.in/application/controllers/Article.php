<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends CI_Controller {
public function __construct()
{
    parent::__construct();

    $this->load->library('form_validation');    
    $this->load->helper('form');
    $this->load->helper('url');
    //$this->load->model('Article_model');
}
public function submit_an_article()
	{
		//echo "dsafd";exit;
		$this->load->view('submit_an_article');
	}
 
  function submit_an_article_add()
	{
			//echo "dsafd";exit;
			if($_POST)
			{
				$Author_Name=$this->input->post('your-name');
				$Paper_Title=$this->input->post('your-subject');
				$Email_Address=$this->input->post('your-email');
				$Contact_No=$this->input->post('your-mobile');
				$About_Us=$this->input->post('how-you-know-aboutus');
				$Attach_Paper=$this->input->post('Attach_Paper');
				$Postal_Address=$this->input->post('postal-address');
				$file_name='';
					   if(isset($_FILES['file-name']['name']))
					   {
						   
							$config['upload_path']=YH_UPLOAD_PATH.'article/';
							
							$config['allowed_types']='pdf';
							$this->load->library('upload',$config);
							if($this->upload->do_upload('file-name'))
							{
								
								$data=$this->upload->data();
								
								$file_name=$data['file_name'];
								
							}
					   }
					  
					   	$Attach_Paper1 = str_replace(" ","_",$file_name);
						$data1= array('Author_Name'=>$Author_Name,'Paper_Title'=>$Paper_Title,'Email_Address'=>$Email_Address,'Contact_No'=>$Contact_No,'About_Us'=>$About_Us,'Attach_Paper'=>$Attach_Paper1,'Postal_Address'=>$Postal_Address);
				
				$res = $this->db->insert('atricle_table',$data1);
				if($res==true)
				{
					$this->session->set_flashdata('success', "successfully add"); 
				}else{
					$this->session->set_flashdata('error', "ERROR_MESSAGE_HERE");
				}
			}
			redirect('submit-an-article');			
	}
	
}  
?> 
	